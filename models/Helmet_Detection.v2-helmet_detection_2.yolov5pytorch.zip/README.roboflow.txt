
Helmet_Detection - v2 Helmet_Detection_2
==============================

This dataset was exported via roboflow.ai on December 9, 2021 at 5:23 AM GMT

It includes 240 images.
WithHelmet-WithoutHelemt are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random brigthness adjustment of between -44 and +44 percent
* Random Gaussian blur of between 0 and 1 pixels


